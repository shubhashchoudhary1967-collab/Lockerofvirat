package com.virat.locker

import android.content.Context
import java.security.MessageDigest

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("lov", Context.MODE_PRIVATE)
    private fun hash(s: String) = MessageDigest.getInstance("SHA-256")
        .digest(("lov:$s").toByteArray()).joinToString("") { "%02x".format(it) }
    fun hasPin(c: Context) = sp(c).contains("pin")
    fun checkPin(c: Context, p: String) = sp(c).getString("pin", null) == hash(p)
    fun setPin(c: Context, p: String) { sp(c).edit().putString("pin", hash(p)).apply() }
    fun locked(c: Context): Set<String> = sp(c).getStringSet("locked", emptySet())!!.toSet()
    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val s = locked(c).toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("locked", s).apply()
    }
}
