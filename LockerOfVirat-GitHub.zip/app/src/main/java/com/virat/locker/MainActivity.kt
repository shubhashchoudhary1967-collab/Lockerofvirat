package com.virat.locker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private var unlocked = false

    override fun onResume() { super.onResume(); show() }
    override fun onStop() { super.onStop(); unlocked = false }

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0b1020")); setPadding(40, 60, 40, 40)
    }
    private fun tv(t: String, sz: Float = 16f, c: String = "#ffffff") =
        TextView(this).apply { text = t; textSize = sz; setTextColor(Color.parseColor(c)); setPadding(0, 8, 0, 8) }
    private fun pinField() = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        gravity = Gravity.CENTER; textSize = 26f; setTextColor(Color.WHITE)
    }

    private fun show() {
        if (!Prefs.hasPin(this)) {
            val r = root(); val f = pinField(); val b = Button(this).apply { text = "Save PIN" }
            r.addView(tv("Locker of Virat", 26f)); r.addView(tv("Create a PIN (4+ digits)", 16f, "#8e97b8")); r.addView(f); r.addView(b)
            b.setOnClickListener { if (f.text.length >= 4) { Prefs.setPin(this, f.text.toString()); unlocked = true; show() } else toast("Minimum 4 digits") }
            setContentView(r); return
        }
        if (!unlocked) {
            val r = root(); val f = pinField(); val b = Button(this).apply { text = "Unlock" }
            r.addView(tv("Locker of Virat", 26f)); r.addView(tv("Enter your PIN", 16f, "#8e97b8")); r.addView(f); r.addView(b)
            b.setOnClickListener { if (Prefs.checkPin(this, f.text.toString())) { unlocked = true; show() } else { toast("Wrong PIN"); f.text.clear() } }
            setContentView(r); return
        }
        val r = root()
        r.addView(tv("Locker of Virat", 26f))
        val acc = isAccessibilityOn(); val ovl = Settings.canDrawOverlays(this)
        r.addView(tv("1. Protection: " + (if (acc) "ON" else "OFF - tap below"), 15f, if (acc) "#3ddc97" else "#ff5c7a"))
        r.addView(Button(this).apply { text = "Enable Protection (Accessibility)"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        r.addView(tv("2. Display over other apps: " + (if (ovl) "ON" else "OFF - tap below"), 15f, if (ovl) "#3ddc97" else "#ff5c7a"))
        r.addView(Button(this).apply { text = "Allow Display Over Apps"; setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
        r.addView(Button(this).apply { text = "Change PIN"; setOnClickListener { changePin() } })
        r.addView(tv("Select apps to lock", 18f))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lockedSet = Prefs.locked(this)
        val apps = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        for ((pkg, label) in apps) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 8, 0, 8) }
            row.addView(TextView(this).apply { text = label; textSize = 16f; setTextColor(Color.WHITE) },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply { text = "Open"; setOnClickListener {
                LockService.allowed = pkg
                packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
            } })
            row.addView(Switch(this).apply { isChecked = lockedSet.contains(pkg); setOnCheckedChangeListener { _, on -> Prefs.setLocked(this@MainActivity, pkg, on) } })
            list.addView(row)
        }
        r.addView(list)
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0b1020")); addView(r) })
    }

    private fun changePin() = askPin("Enter old PIN") { old ->
        if (!Prefs.checkPin(this, old)) { toast("Wrong PIN"); return@askPin }
        askPin("Enter new PIN") { np ->
            if (np.length < 4) { toast("Minimum 4 digits"); return@askPin }
            AlertDialog.Builder(this).setTitle("Save new PIN?")
                .setPositiveButton("Save") { _, _ -> Prefs.setPin(this, np); toast("New PIN saved") }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun askPin(title: String, cb: (String) -> Unit) {
        val f = pinField().also { it.setTextColor(Color.BLACK) }
        AlertDialog.Builder(this).setTitle(title).setView(f)
            .setPositiveButton("OK") { _, _ -> cb(f.text.toString()) }.setNegativeButton("Cancel", null).show()
    }

    private fun isAccessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
