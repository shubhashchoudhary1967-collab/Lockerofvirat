package com.virat.locker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*

class LockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pkg = intent.getStringExtra("pkg") ?: ""
        val name = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0b1020")); setPadding(64, 64, 64, 64)
        }
        fun tv(t: String, sz: Float, c: String) = TextView(this).apply { text = t; textSize = sz; setTextColor(Color.parseColor(c)); gravity = Gravity.CENTER }
        val msg = tv("Enter PIN to open $name", 16f, "#8e97b8")
        val pin = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            gravity = Gravity.CENTER; textSize = 28f; setTextColor(Color.WHITE)
        }
        val go = Button(this).apply { text = "Unlock" }
        box.addView(tv("Locker of Virat", 26f, "#ffffff"))
        box.addView(msg); box.addView(pin); box.addView(go)
        setContentView(box)
        go.setOnClickListener {
            if (Prefs.checkPin(this, pin.text.toString())) {
                LockService.allowed = pkg
                finish()
            } else { msg.text = "Wrong PIN. Try again."; pin.text.clear() }
        }
    }

    @Deprecated("deprecated")
    override fun onBackPressed() { goHome() }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
